package com.android.rivchat.model;



public class Friend extends User{
    public String id;
    public String idRoom;
}
